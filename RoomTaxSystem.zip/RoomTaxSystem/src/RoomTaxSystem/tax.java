package RoomTaxSystem;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class tax {

	public static void main(String[] args) throws FileNotFoundException{
		// Create the Scanner
		String fileName = "rooms.txt";
		FileReader file = new FileReader(fileName);
		Scanner read = new Scanner(file);

		// read and process the next input
		while (read.hasNext()) {
			String line = read.nextLine();
			System.out.println(line);
		}

		// Close the scanner now that we have finished with it
		read.close();
	}

}
